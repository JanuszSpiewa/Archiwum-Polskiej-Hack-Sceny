// transfer.c - by Permssion Denied
// short program to get/put data streams from some opened port
// part of Prisioner of Gates System project

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

int main (int argc, char **argv)
{
 struct sockaddr_in sin;
 int sock;
 char c;
 struct hostent *phe;
 int f;
 
 if(argc<4) {
  printf("%s <p|g> <ip> <port> (<name>)\n", argv[0]);return;
  }
 bzero((char *) &sin, sizeof(sin));
 sin.sin_family = AF_INET;
 sin.sin_port = htons(atoi(argv[3]));
 if (phe = gethostbyname (argv[2]))
  bcopy(phe -> h_addr, (char *) &sin.sin_addr, phe -> h_length);
  else
  {
   fprintf(stderr, "No host\n");return;
  }
 if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP))<0) {
  fprintf(stderr, "No free socket\n");return;
  }
 if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
  fprintf(stderr, "No connect\n"); return;
  }
 if (strcmp(argv[1], "g")==0) 
  while(read(sock, &c, 1)>0) printf("%c", c);
  else {
  if((f = open(argv[4], O_RDONLY, S_IREAD)) == -1) {
   fprintf(stderr, "No file\n"); return;
   }
  while(read(f, &c, 1)>0) write(sock, &c, 1);
  close(f);
  }
 printf("%d\n", errno);
 close(sock);
 }  