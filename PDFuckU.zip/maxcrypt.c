// maxcrypt.c - by Permission Denied (Maxiu)
// easy and fast file coder/decoder with password
// if no argument is given, input is from stdin and output to stdout

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>

#define BUFLEN 1024

char dobyte (char *p1, char *p2, int len)
{
 // count coding-byte from -len- bytes from -p1- & -p2- buffer
 int c, t = 0;

 for(c = 1; c <= len; c++, p2++, p1++)
  t += (p1[0] * c + (p1[0] >> 2) + p2[0] * c + (p2[0] >> 2)) >> 1;  
 return (t + (t >> 8));
}

int maxcrypt (int s, int d, char *p1, int len, int buflen)
{
 // crypts file -s-, writing output to -d-, password at -p1- with -len- length
 // buffer -p1- must habe -buflen- length and must be minimum 2x -len-
 // it also decrypts :)
 
 char *data1; // pointer to -p1- + -len-
 char p2[buflen]; // second buffer
 char *data2; // pointer to -p2- + -len-
 int tmp, datalen = 0; // length of read data
 int cur = 0; // current position in -data-
 int fin = 0; // flag if finished work
 
 if((len >> 1) > buflen) return 1;
 data1 = p1 + len;
 memcpy(p2, p1, len); // move password to second buffer
 data2 = p2 + len;
 
 while(1) {
  if (datalen == cur) {
   write(d, data2, cur); // save buffered data
   cur = 0;
   if(fin) return 0;
   // copy important bytes
   memcpy(p1, p1 + datalen, len);
   memcpy(p2, p2 + datalen, len);
   // we must read MINIMUM len bytes (unless end of file)!
   datalen = 0; tmp = 1;
   while(datalen < len && tmp) 
    if((datalen += tmp = read(s, data1 + datalen, buflen - len - datalen)) < 0)
     return 1;
   if(datalen == 0) {
    fin = 1;
    continue;
   }
  }
  data2[cur] = data1[cur] ^ dobyte(p1 + cur, p2 + cur, len);
  cur++;
 }
}

main (int argc, char **argv) {
 char buf[BUFLEN]="\0", ch;
 int s, d, o = 2;
 
 s = fileno(stdin);
 d = fileno(stdout);

 while ((ch = getopt(argc, argv, "ho:p:")) != EOF) {
  switch (ch) {
   case 'o':	d = open(optarg, O_CREAT | O_WRONLY | O_TRUNC,
                                 S_IRUSR | S_IWUSR);
   		break;
   case 'p':	strncpy(buf, optarg, BUFLEN >> 1); o++;
   		break;
   case 'h':
   default:
	printf("MaxCrypt, universal file crypter by Permssion Denied (Maxiu)\n");
	printf("Usage:\n %s [<infile>] [-o <outfile>] [-p <password>] [-h]\n", argv[0]);
	return 1;
   }
  }
 argc -= optind;
 argv += optind;
 
 if(argc>0)
  s = open(argv[0], O_RDONLY);

 if(!strlen(buf)) {
  strcpy(buf, getpass("Enter password: "));
 }
 
 if(maxcrypt(s, d, buf, strlen(buf), BUFLEN)) printf("Error when (de)crypting\n");
 
 close(d);
 close(s);
}