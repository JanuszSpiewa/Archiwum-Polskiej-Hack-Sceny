// backnet.c - by Permission Denied
// pure and weak program to connect FROM some port

#include <stdio.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <errno.h>
#include <sys/time.h>

#define SPORT 2000;

struct sockaddr_in sind, server;
int sock;

main (int argc, char **argv)
{
 int sport, port, cc;
 struct hostent *fhe;

 fd_set arfds, awfds, rfds, wfds;
 char line[1000];
   
 if(argc<3 || argc>4) {
  printf("BackNet by Maxiu\nUsage:\n %s <host> <port> [<s_port>]\n", argv[0]);
  return;
 }
 if(argc==4) sport = atoi(argv[3]); 
  else sport = SPORT;
 port = atoi(argv[2]);
 bzero((char *) &sind, sizeof(sind));
 sind.sin_family = AF_INET;
 if (fhe = gethostbyname(argv[1]))
  bcopy(fhe -> h_addr, (char *) &sind.sin_addr, fhe -> h_length);
  else {
   printf("No host\n"); return;
  }
 sind.sin_port = htons(port);
 sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
 bzero((char *) &server, sizeof(server));
 server.sin_family = AF_INET;
 server.sin_addr.s_addr = INADDR_ANY;
 server.sin_port = htons(sport);
 if(bind(sock, (struct sockaddr *) &server, sizeof(server))) {
  printf("Bind error\n");
  return;
 }
 if(connect(sock, (struct sockaddr *) &sind, sizeof(sind)) != 0) {
  if(errno == ECONNREFUSED) printf("Connection refused\n"); else
   printf("Cannot connect\n");
  return;
 }
 FD_ZERO(&awfds);
 FD_ZERO(&arfds);
 FD_SET(sock, &arfds);
 FD_SET(0, &arfds);
 while (1) {
  bcopy((char *)&arfds, (char *)&rfds, sizeof(rfds));
  bcopy((char *)&awfds, (char *)&wfds, sizeof(wfds));
  if(select(getdtablesize(), &rfds, &wfds, (fd_set *) 0, (struct timeval *) 0) < 0)
   {
    if (errno == EINTR) continue;
    printf("Connecion closed\n");
    break;
   }
  if (FD_ISSET(sock, &rfds)) {
   cc = read(sock, (char *) line, 1000);
   if(cc < 0) {
    printf("socket read error: %d\n", errno);
    break;
   }
   else if (cc == 0) {
    printf("\nConnection closed\n");
    break;
   }
   else
   {
    line[cc]='\0';
    fputs(line, stdout);
   }
  }
  if(FD_ISSET(0, &rfds)) {
   cc = read(0, (char *) line, 1000);
   if (cc<0) {
    printf("stdin read error: %d\n", errno);
    break;
   } else if (cc == 0) {
    printf("\nConnection closed\n");
    break;
   } else
   if(write(sock, line, cc) < 0) {
    printf("socket write error: %d\n", errno);
    break;
   }
  }
 }
 close(sock);
}
